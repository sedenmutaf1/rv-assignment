package com.example.myrvexample.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myrvexample.R
import com.example.myrvexample.UserDetailActivity
import com.example.myrvexample.model.User

class ItemAdapter(private val data: List<User>) : RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        private lateinit var employee: User
        val nameTextView: TextView = view.findViewById(R.id.nameTV)
        val jobTitleTextView: TextView = view.findViewById(R.id.jobTitleTextView)
        val departmentTextView: TextView = view.findViewById(R.id.departmentTextView)
        val phoneNumberTextView: TextView = view.findViewById(R.id.phoneNumberTextView)

        init {
            view.setOnClickListener {
                val context = itemView.context
                val detailIntent = Intent(context, UserDetailActivity::class.java)

                // Pass each employee detail as an Intent extra
                detailIntent.putExtra("employee_name", employee.employee_name)
                detailIntent.putExtra("job_title", employee.job_title)
                detailIntent.putExtra("department", employee.department)
                detailIntent.putExtra("phone_number", employee.phone_number)

                context.startActivity(detailIntent)
            }
        }

        fun bind(employee: User) {
            this.employee = employee
            nameTextView.text = employee.employee_name
            jobTitleTextView.text = employee.job_title
            departmentTextView.text = employee.department
            phoneNumberTextView.text = employee.phone_number
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout, parent, false)
        return ItemViewHolder(view)
    }

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val employee = data[position]
        holder.bind(employee)
    }
}
