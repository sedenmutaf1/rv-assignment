package com.example.myrvexample

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.databinding.DataBindingUtil
import com.example.myrvexample.databinding.ActivityUserDetailBinding

class UserDetailActivity : AppCompatActivity() {

    companion object {
        const val EMPLOYEE_NAME = "employee_name"
        const val JOB_TITLE = "job_title"
        const val DEPARTMENT = "department"
        const val PHONE_NUMBER = "phone_number"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Use Data Binding to set the content view
        val binding: ActivityUserDetailBinding = DataBindingUtil.setContentView(this, R.layout.activity_user_detail)

        // Retrieve employee details from intent extras
        val employeeName = intent.getStringExtra(EMPLOYEE_NAME)
        val jobTitle = intent.getStringExtra(JOB_TITLE)
        val department = intent.getStringExtra(DEPARTMENT)
        val phoneNumber = intent.getStringExtra(PHONE_NUMBER)

        // Bind data to views in the layout
        binding.nameView.text = employeeName
        binding.jobTitleView.text = jobTitle
        binding.departmentView.text = department
        binding.phoneView.text = phoneNumber

        // Apply edge-to-edge insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
