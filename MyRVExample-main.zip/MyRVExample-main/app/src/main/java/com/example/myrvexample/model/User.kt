package com.example.myrvexample.model

import java.io.Serializable

data class User(
    val employee_name: String,
    val job_title: String,
    val department: String,
    val phone_number: String,
) : Serializable
